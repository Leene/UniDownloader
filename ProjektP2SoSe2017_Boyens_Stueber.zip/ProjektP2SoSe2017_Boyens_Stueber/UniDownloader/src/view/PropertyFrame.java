package view;

import javax.swing.JDialog;

public class PropertyFrame extends JDialog{

	public PropertyFrame() {
//		
	}

}
