package main;


import view.BaseFrame;

public class Main {

	public static void main(String[] args) {
		 new BaseFrame();
		
	}

}
